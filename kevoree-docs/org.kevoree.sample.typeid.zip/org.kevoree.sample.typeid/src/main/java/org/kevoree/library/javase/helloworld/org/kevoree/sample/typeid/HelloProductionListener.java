package org.kevoree.library.javase.helloworld.org.kevoree.sample.typeid;

/**
 * Created by IntelliJ IDEA.
 * User: gnain
 * Date: 27/10/11
 * Time: 14:36
 * To change this template use File | Settings | File Templates.
 */
public interface HelloProductionListener {

    public void helloProduced(String helloValue);
}
